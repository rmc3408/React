import React from 'react';
import { RollDice } from './components/RollDice';
import './App.css';

function App() {
  return (
    <div className="App">
      <RollDice />
    </div>
  );
}

export default App;
