import React from 'react';
import { CoinFlip } from './components/CoinFlip';
import './App.css';

function App() {
  return (
    <div className="App">
      <CoinFlip />
    </div>
  );
}

export default App;
