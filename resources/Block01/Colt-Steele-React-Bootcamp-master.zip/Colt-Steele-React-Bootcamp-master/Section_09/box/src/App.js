import React from 'react';
import { BoxContainer } from './components/BoxContainer';
import './App.css';

function App() {
  return (
    <div className="App">
      <BoxContainer />
    </div>
  );
}

export default App;
