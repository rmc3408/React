import React from 'react'
import './App.css'

import CardGame from './CardGame'

function App() {
  return (
    <div className="App">
      <CardGame />
    </div>
  )
}

export default App
