import React from 'react'
import './App.css'

import BoxList from './BoxList'

function App() {
  return (
    <div className="App">
      <BoxList />
    </div>
  )
}

export default App
