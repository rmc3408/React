import React, { Component } from 'react'
import './App.css'

import CoinGame from './CoinGame'

class App extends Component {
  render() {
    return (
      <div className="App">
        <CoinGame />
      </div>
    )
  }
}

export default App
