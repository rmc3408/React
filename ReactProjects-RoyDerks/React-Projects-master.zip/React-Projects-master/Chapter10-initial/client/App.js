import React from 'react';
import AppContainer from './AppContainer';

const App = () => <AppContainer />;

export default App;
